<template>
  <div class="footer">
    <img src="../assets/footer.png" alt="">
  </div>
</template>

<script>
export default {
  name: 'Footer'
}
</script>

<style lang="scss">
  .footer{
    width: 100%;
    text-align: center;
    background: rgb(102, 102, 102);
    padding: 50px 0;
  }
</style>
