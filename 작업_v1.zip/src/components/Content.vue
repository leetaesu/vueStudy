<template>
  <div class="Content">
    <a href="http://fs.joycity.com/web/main.do?_ga=2.51733228.474652086.1589803198-941195160.1588233956" target="_blank" rel="noopener noreferrer"><img src="https://common-cdn-api.joycityglobal.com/portal/common/img/img_customer_center1.jpg" alt=""></a>
    <a href="https://fs2.joycity.com/web/main.do?_ga=2.51733228.474652086.1589803198-941195160.1588233956" target="_blank" rel="noopener noreferrer"><img src="https://common-cdn-api.joycityglobal.com/portal/common/img/img_customer_center2.jpg" alt=""></a>
    <a href="http://fsfz.game.naver.com/" target="_blank" rel="noopener noreferrer"><img src="https://common-cdn-api.joycityglobal.com/portal/common/img/img_customer_center3.jpg" alt=""></a>
  </div>
</template>

<script>
export default {
  name: 'Content'
}
</script>

<style lang="scss">
  .Content{
    width: 100%;
    text-align: center;
    background: #000;
  }
</style>
