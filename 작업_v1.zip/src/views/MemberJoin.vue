<template>
  <div class="memberJoin">
      <Header></Header>
      <img src="../assets/member.png" alt="">
  </div>
</template>

<script>
// @ is an alias to /src
import Header from '@/components/Header.vue'
export default {
  name: 'MemberJoin',
  components: {
    Header
  }
}
</script>
